TRAXSHOP V1 - PROTOTYPE E-COMMERCE

Demo login:
ID pelanggan: PLG001
Nomor HP: 081234567890
Password: 123456

Fitur:
- Login ID/nomor HP
- Dashboard pelanggan
- Saldo
- Katalog produk
- Pencarian
- Keranjang
- Checkout
- Riwayat pesanan
- Responsive HP/laptop

PENTING:
Ini prototype frontend. Data masih berada di browser dan belum menjadi database online.
Untuk versi produksi diperlukan hosting + database + autentikasi server + payment gateway + panel admin.
